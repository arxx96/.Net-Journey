﻿using Microsoft.AspNetCore.Mvc;
using ToDoMVC.Data;
using ToDoMVC.Models;
using ToDoMVC.Migrations;
using System.Net;

namespace ToDoMVC.Controllers
{
    public class todoController : Controller
    {

        private readonly ApplicationDBcontext _db;


        public todoController(ApplicationDBcontext db) { 
            _db = db;
        }
        public IActionResult Index()
        {
            var todoobj = _db.todos.ToList();
            return View(todoobj);
        }



        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Todo obj)
        {
            if ((obj.Name != null)&& (obj.Name.ToLower() == "test"))
            {
                ModelState.AddModelError("Name", "todo cant be test");
            }
            if (ModelState.IsValid)
            {
                _db.todos.Add(obj);

                _db.SaveChanges();
                TempData["success"] = "Add ToDo List";

                return RedirectToAction("Index");
            }
            else
            {
                TempData["error"] = "error";
                return View(obj);
            }
           
        }


        public IActionResult Update(int id)
        {
            

            var data = _db.todos.FirstOrDefault(x => x.Id == id);
            return View(data);
        }

        [HttpPost]

        public IActionResult Update(Todo obj) {

            // var data =_db.todos.FirstOrDefault(x => x.Id == id);
          
            _db.todos.Update(obj);
            _db.SaveChanges();
            TempData["success"] = "Update ToDo List";
            return RedirectToAction("Index");
        
        }
        public IActionResult Delete(int id)

        {
            var data = _db.todos.FirstOrDefault(x => x.Id == id);

            _db.todos.Remove(data);

            _db.SaveChanges();
            TempData["success"] = "delete ToDo List";
            return RedirectToAction("Index");

        }


       
    }
}
