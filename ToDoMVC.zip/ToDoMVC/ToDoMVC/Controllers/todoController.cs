﻿using Microsoft.AspNetCore.Mvc;
using ToDoMVC.Data;
using ToDoMVC.Models;
using ToDoMVC.Migrations;
using System.Net;

namespace ToDoMVC.Controllers
{
    public class todoController : Controller
    {

        private readonly ApplicationDBcontext _db;


        public todoController(ApplicationDBcontext db) { 
            _db = db;
        }
        public IActionResult Index()
        {
            var todoobj = _db.todos.ToList();
            return View(todoobj);
        }



        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Todo obj)

        {
            _db.todos.Add(obj);

            _db.SaveChanges();
            return RedirectToAction("Index");

        }


        public IActionResult Update(int id)
        {
            

            var data = _db.todos.FirstOrDefault(x => x.Id == id);
            return View(data);
        }

        [HttpPost]

        public IActionResult Update(Todo obj) {

            // var data =_db.todos.FirstOrDefault(x => x.Id == id);
          
            _db.todos.Update(obj);
            _db.SaveChanges();
            return RedirectToAction("Index");
        
        }
        public IActionResult Delete(int id)

        {
            var data = _db.todos.FirstOrDefault(x => x.Id == id);

            _db.todos.Remove(data);

            _db.SaveChanges();
            return RedirectToAction("Index");

        }


        //    public ActionResult Delete(Todo obj, int id = 0)
        //  {
        //    _db.todos.Find(id);
        //  if (obj == null)
        //{
        //  return HttpNotFound();
        //}
        // _db.todos.Remove(obj);
        // _db.SaveChanges();
        // return RedirectToAction("Index");
        //}
    }
}
