﻿
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure.Internal;
using Microsoft.Identity.Client;
using ToDoMVC.Models;

namespace ToDoMVC.Data
{
    public class ApplicationDBcontext:DbContext
    {
        public ApplicationDBcontext(DbContextOptions<ApplicationDBcontext> option) : base (option) {
        
        
        
        }
        public DbSet<Todo> todos { get; set; }
    }
}
