﻿namespace Razortest2.Model
{
    public class Todoing
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Order { get; set; }
    }
}
