using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Razortest2.data;
using Razortest2.Model;

namespace Razortest2.Pages
{
    public class CreateModel : PageModel
    {

        private readonly ApplicationDBcontext _db;
        [BindProperty]
        public Todoing todoingList { get; set; }

        public CreateModel(ApplicationDBcontext db)
        {
            _db = db;
        }
        public void OnGet()
        {
        }
        public IActionResult OnPost() {
            _db.todoings.Add(todoingList);
        _db.SaveChanges();
            return RedirectToPage("Index");
        
        }
    }
}
