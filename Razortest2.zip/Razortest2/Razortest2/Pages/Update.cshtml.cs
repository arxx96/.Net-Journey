using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Razortest2.data;
using Razortest2.Model;

namespace Razortest2.Pages
{
    public class UpdateModel : PageModel
    {
        private readonly ApplicationDBcontext _db;
        [BindProperty]
        public Todoing todoingList { get; set; }

        public UpdateModel(ApplicationDBcontext db)
        {
            _db = db;
        }
        public void OnGet(int? id)
        {
            todoingList = _db.todoings.Find(id);
        }
        public IActionResult OnPost()
        {
            _db.todoings.Update(todoingList);
            _db.SaveChanges();
            return RedirectToPage("Index");

        }
    }
}
