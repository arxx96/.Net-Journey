using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Razortest2.data;
using Razortest2.Model;

namespace Razortest2.Pages
{
    public class DeleteModel : PageModel
    {


        private readonly ApplicationDBcontext _db;
        [BindProperty]
        public Todoing todoingList { get; set; }

        public DeleteModel(ApplicationDBcontext db)
        {
            _db = db;
        }
       
        public IActionResult OnGet(int? id)
        {
            todoingList = _db.todoings.Find(id);
            _db.todoings.Remove(todoingList);
            _db.SaveChanges();
            return RedirectToPage("Index");

        }
      
    }
}
