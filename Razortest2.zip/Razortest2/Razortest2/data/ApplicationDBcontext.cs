﻿using Microsoft.EntityFrameworkCore;
using Razortest2.Model;

namespace Razortest2.data
{
    public class ApplicationDBcontext : DbContext
    {
        public ApplicationDBcontext(DbContextOptions<ApplicationDBcontext> option) : base(option)
        {



        }
       public DbSet<Todoing> todoings { get; set; }

    }
}
